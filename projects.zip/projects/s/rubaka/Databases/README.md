Signature Database Structure
================================


Header Scheme
-----------------

- Database version : Last update : Number of Signatures :


	------
	
	ex: 1.0:10/10/2013:50:

	------


Signature Scheme
-----------------

-  Virus Name : Signature :


	-----
	
	ex: Test Virus_1:0A445F6ABC8:
	
	------
