#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

#ifndef NDBtoDB_H
#define NDBtoDB_H

void NDBtoDbConverter(char* NDBfile,char* DBfile);
//int getLineCount(char* file);

#endif