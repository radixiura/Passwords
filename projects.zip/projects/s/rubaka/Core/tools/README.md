==========================
Contains stand alone tools
==========================