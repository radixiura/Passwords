/*
 * OS.h
 *
 *  Created on: Apr 18, 2014
 *      Author: abd-el-rahman
 */

#ifndef OS_H_
#define OS_H_
#include <string>
#include<iostream>
namespace OS{

//	void closeProcess(std::string executablePath){
//		std::cout<<"Linux";
//	}
}



#endif /* OS_H_ */
