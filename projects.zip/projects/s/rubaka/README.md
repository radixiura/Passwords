C++ Open Source Anti-virus 
==========================================

C++ Implementation of an Anti-virus that have the following features :

- GUI / CLI Interface

- Signature based scanning technique as a start and more techniques can be added later

- Tools for Signature Database Creation
