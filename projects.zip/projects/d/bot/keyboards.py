# Импорты
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


# Приветственная клавиатура
p5_hello_btn1 = InlineKeyboardButton("Магазин (🆕)", callback_data="p5_shop_signal")
p5_hello_btn2 = InlineKeyboardButton("Кошелек", callback_data="p5_wallet_signal")
p5_hello_btn3 = InlineKeyboardButton("Работа", callback_data="p5_work_signal")
p5_hello_btn4 = InlineKeyboardButton("Поддержка", callback_data="p5_support_signal")

p5_hello_mrkp = InlineKeyboardMarkup(row_width=2).add(p5_hello_btn1) \
    .add(p5_hello_btn2) \
    .add(p5_hello_btn3) \
    .add(p5_hello_btn4) 


# ----- #

# Кошелек
p5_wallet_btn1 = InlineKeyboardButton("Мой кошелек", switch_inline_query_current_chat='3LihbJYiVXYu65i6ToMq4HfZ2ia9gHSXVn')
p5_wallet_btn2 = InlineKeyboardButton("Назад 🔙", callback_data="p5_get_back_main_menu_signal")

p5_wallet_mrkp = InlineKeyboardMarkup(row_width=2).add(p5_wallet_btn1) \
    .add(p5_wallet_btn2)


# Работа
p5_work_btn1 = InlineKeyboardButton("Курьер", callback_data="p5_work_courier_signal")
p5_work_btn2 = InlineKeyboardButton("Дизайнер", callback_data="p5_work_design_signal")
p5_work_btn3 = InlineKeyboardButton("Франшиза", callback_data="p5_work_franchise_signal")
p5_work_btn4 = InlineKeyboardButton("Назад", callback_data="p5_get_back_main_menu_signal")

p5_work_mrkp = InlineKeyboardMarkup(row_width=2).add(p5_work_btn1) \
    .add(p5_work_btn2) \
    .add(p5_work_btn3) \
    .add(p5_work_btn4)
    
    
# Поддержка
p5_support_btn1 = InlineKeyboardButton("Инструкция и FAQ", callback_data="p5_support_faq_signal")
p5_support_btn2 = InlineKeyboardButton("Обратная связь", callback_data="p5_support_feedback_signal")
p5_support_btn3 = InlineKeyboardButton("Поставщикам", callback_data="p5_support_toproviders_signal")
p5_support_btn4 = InlineKeyboardButton("О нас", callback_data="p5_support_about_signal")
p5_support_btn5 = InlineKeyboardButton("Назад 🔙", callback_data="p5_get_back_main_menu_signal")

p5_support_mrkp = InlineKeyboardMarkup(row_width=2).add(p5_support_btn1) \
    .add(p5_support_btn2) \
    .add(p5_support_btn3) \
    .add(p5_support_btn4) \
    .add(p5_support_btn5)
