# Импорты
from aiogram import Bot, types
from aiogram.utils import executor
from aiogram.dispatcher import Dispatcher

from conf import config

import keyboards as kb

# Начало работы
bot = Bot(token=config.bot_token)
dp = Dispatcher(bot)


# Команды
@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message):
    await message.reply(f"Привет, {message.from_user.first_name}!",
                        reply_markup=kb.p5_hello_mrkp)




# Магазин
@dp.callback_query_handler(lambda c: c.data == "zaym")
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "Введите нужную вам сумму (100 - 10000):",
                           reply_markup=kb.p5_shop_mrkp)


# ----- #

# Обработчики для кнопок				
@dp.callback_query_handler(lambda c: c.data == "p5_get_back_main_menu_signal")
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "Возврат к главному меню:",
                           reply_markup=kb.p5_hello_mrkp)


# ----- #


# Кошелек 
@dp.callback_query_handler(lambda c: c.data == "p5_wallet_signal")
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "🤑",
                           reply_markup=kb.p5_wallet_mrkp)


# Работа
@dp.callback_query_handler(lambda c: c.data == "p5_work_signal")
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "🤑",
                           reply_markup=kb.p5_work_mrkp)


# Поддержка
@dp.callback_query_handler(lambda c: c.data == "p5_support_signal")
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "Выберите действие:",
                           reply_markup=kb.p5_support_mrkp)


# Запуск проверки сообщений
if __name__ == '__main__':
    executor.start_polling(dp)
