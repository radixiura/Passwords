# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from buttons.main_buttons import *
from buttons.shop_buttons import *
from buttons.funds_buttons import *
from buttons.work_buttons import *
from buttons.support_buttons import *

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support

from vars import cities, districts, products
#-IMPORTS-#


# MAIN KEYBOARD #
p5_main_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_main_buttons)
#-MAIN KEYBOARD-#


# SHOP KEYBOARD #
p5_shop_mrkp = InlineKeyboardMarkup(row_width=2).add(*p5_shop_buttons)
#-SHOP KEYBOARD-#


## SHOP.MOSCOW ##
p5_shop_mow_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_buttons)

p5_shop_mow_hash_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_hash_buttons)
p5_shop_mow_heads_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_heads_buttons)
p5_shop_mow_mephflour_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_mephflour_buttons)
p5_shop_mow_mephcryst_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_mephcryst_buttons)
p5_shop_mow_apvp_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_mow_apvp_buttons)
##-SHOP.MOSCOW-##


## SHOP.IVANOVO ##
p5_shop_iwa_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_iwa_buttons)

p5_shop_iwa_heads_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_iwa_heads_buttons)
p5_shop_iwa_mephcryst_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_iwa_mephcryst_buttons)
p5_shop_iwa_apvp_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_iwa_apvp_buttons)
##-SHOP.IVANOVO-##


## SHOP.PETROZAVODSK ##
p5_shop_pes_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_pes_buttons)

p5_shop_pes_hash_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_pes_hash_buttons)
p5_shop_pes_heads_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_pes_heads_buttons)
p5_shop_pes_mephcryst_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_pes_mephcryst_buttons)
p5_shop_pes_apvp_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_pes_apvp_buttons)


p5_shop_purchase_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_shop_purchase_buttons)
##-SHOP.PETROZAVODSK-##
#-SHOP KEYBOARDS-#


# FUNDS KEYBOARDS #
p5_funds_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_funds_buttons)

p5_funds_wallet_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_funds_wallet_buttons)
p5_funds_wallet_withdrawal_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_funds_wallet_withdrawal_buttons)
#-FUNDS KEYBOARDS-#


# WORK KEYBOARDS #
p5_work_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_work_buttons)
#-WORK KEYBOARDS-#


# SUPPORT KEYBOARDS #
p5_support_mrkp = InlineKeyboardMarkup(row_width=1).add(*p5_support_buttons)
#-SUPPORT KEYBOARDS-#
