# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support
from vars import cities, districts, products
#-IMPORTS-#



p5_funds_buttons = [
    InlineKeyboardButton("Кошелек и вывод средств", callback_data=funds.new('p5_funds_wallet_signal')),
    InlineKeyboardButton("Мой BTC - кошелек", callback_data=funds.new('p5_funds_btcwallet_signal')),
    InlineKeyboardButton("Мои купоны", callback_data=funds.new('p5_funds_coupons_signal')),
    InlineKeyboardButton("Назад 🔙", callback_data=funds.new("p5_main_menu_signal"))
]

p5_funds_wallet_buttons = [
    InlineKeyboardButton("Баланс", callback_data=funds_wallet.new('p5_funds_wallet_balance_signal')),
    InlineKeyboardButton("Вывод средств", callback_data=funds_wallet.new('p5_funds_wallet_withdrawal_signal')),
    InlineKeyboardButton("Назад 🔙", callback_data=funds_wallet.new("p5_main_menu_signal"))
]

p5_funds_wallet_withdrawal_buttons = [
    InlineKeyboardButton("По номеру карты", callback_data=funds_wallet_withdrawal.new('p5_funds_wallet_withdrawal_card_signal')),
    InlineKeyboardButton("На QIWI - кошелек", callback_data=funds_wallet_withdrawal.new('p5_funds_wallet_withdrawal_qiwi_signal')),
    InlineKeyboardButton("На BTC - кошелек", callback_data=funds_wallet_withdrawal.new('p5_funds_wallet_withdrawal_btcwallet_signal')),
    InlineKeyboardButton("Назад 🔙", callback_data=funds_wallet_withdrawal.new('p5_main_menu_signal'))
]
