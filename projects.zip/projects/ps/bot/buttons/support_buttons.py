# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support
from vars import cities, districts, products
#-IMPORTS-#


p5_support_buttons = [
    InlineKeyboardButton("Инструкция и FAQ", callback_data=support.new('p5_support_instruction_signal')),
    InlineKeyboardButton("Обратная связь", callback_data=support.new('p5_support_feedback_signal')),
    InlineKeyboardButton("О нас", callback_data=support.new('p5_support_about_signal')),
    InlineKeyboardButton("Назад 🔙", callback_data=support.new('p5_main_menu_signal'))
]
