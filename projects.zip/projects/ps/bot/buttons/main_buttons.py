# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
#-IMPORTS-#


p5_main_buttons = [
    InlineKeyboardButton("Магазин 🆕", callback_data="p5_shop_signal"),
    InlineKeyboardButton("Средства", callback_data="p5_funds_signal"),
    InlineKeyboardButton("Работа", callback_data="p5_work_signal"),
    InlineKeyboardButton("Поддержка", callback_data="p5_support_signal"),
    InlineKeyboardButton("Отзывы 🆕", callback_data="p5_reviews_signal")
]
