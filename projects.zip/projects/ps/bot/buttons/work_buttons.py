# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support
from vars import cities, districts, products
#-IMPORTS-#



p5_work_buttons = [
    InlineKeyboardButton("Курьер", callback_data=work.new('p5_work_courier_signal')),
    InlineKeyboardButton("Граффитчик", callback_data=work.new('p5_work_artist_signal')),
    InlineKeyboardButton("Дизайнер", callback_data=work.new('p5_work_designer_signal')),
    InlineKeyboardButton("Рекламщик", callback_data=work.new('p5_work_advertiser_signal')),
    InlineKeyboardButton("Назад 🔙", callback_data=work.new('p5_main_menu_signal'))
]
