# IMPORTS #
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support
from vars import cities, districts, products
#-IMPORTS-#



p5_shop_buttons = [
    InlineKeyboardButton(text=f'{city}', callback_data=call_city.new(city))
    for city in cities.cities
]




p5_shop_mow_buttons = [
    InlineKeyboardButton(f"{products.hash1} = {products.hash1_price}", callback_data=pos_variable.new('hash_mow')),
    InlineKeyboardButton(f"{products.heads1} = {products.heads1_price}", callback_data=pos_variable.new('heads_mow')),
    InlineKeyboardButton(f"{products.mephflour1} = {products.mephflour1_price}", callback_data=pos_variable.new('mephflour_mow')),
    InlineKeyboardButton(f"{products.mephcryst1} = {products.mephcryst1_price}", callback_data=pos_variable.new('mephcryst_mow')),
    InlineKeyboardButton(f"{products.apvp1} = {products.apvp1_price}", callback_data=pos_variable.new('apvp_mow')),
    InlineKeyboardButton("Назад 🔙", callback_data=pos_variable.new('back'))
]

p5_shop_iwa_buttons = [
    InlineKeyboardButton(f"{products.heads1} = {products.heads1_price}", callback_data=pos_variable.new('heads_iwa')),
    InlineKeyboardButton(f"{products.mephcryst1} = {products.mephcryst1_price}", callback_data=pos_variable.new('mephcryst_iwa')),
    InlineKeyboardButton(f"{products.apvp1} = {products.apvp1_price}", callback_data=pos_variable.new('apvp_iwa')),
    InlineKeyboardButton("Назад 🔙", callback_data=pos_variable.new('back'))
]

p5_shop_pes_buttons = [
    InlineKeyboardButton(f"{products.hash1} = {products.hash1_price}", callback_data=pos_variable.new('hash_pes')),
    InlineKeyboardButton(f"{products.heads1} = {products.heads1_price}", callback_data=pos_variable.new('heads_pes')),
    InlineKeyboardButton(f"{products.mephcryst1} = {products.mephcryst1_price}", callback_data=pos_variable.new('mephcryst_pes')),
    InlineKeyboardButton(f"{products.apvp1} = {products.apvp1_price}", callback_data=pos_variable.new('apvp_pes')),
    InlineKeyboardButton("Назад 🔙", callback_data=pos_variable.new('back'))
]



# MOW PRODUCTS 
p5_shop_mow_hash_buttons = [
    InlineKeyboardButton(f"{districts.mow_metro4}, Тайник", callback_data=hash_mow.new(1)),
    InlineKeyboardButton(f"{districts.mow_metro6}, Магнит", callback_data=hash_mow.new(2)),
    InlineKeyboardButton(f"{districts.mow_metro39}, Магнит", callback_data=hash_mow.new(3)),
    InlineKeyboardButton(f"{districts.mow_metro45}, Магнит", callback_data=hash_mow.new(4)),
    InlineKeyboardButton(f"{districts.mow_metro50}, Магнит", callback_data=hash_mow.new(5)),
    InlineKeyboardButton(f"{districts.mow_metro55}, Тайник", callback_data=hash_mow.new(6)),
    InlineKeyboardButton(f"{districts.mow_metro115}, Магнит", callback_data=hash_mow.new(7)),
    InlineKeyboardButton(f"{districts.mow_distr1}, Тайник", callback_data=hash_mow.new(8)),
    InlineKeyboardButton(f"{districts.mow_distr2}, Магнит", callback_data=hash_mow.new(9)),
    InlineKeyboardButton("Назад 🔙", callback_data=hash_mow.new('back_mow'))
]

p5_shop_mow_heads_buttons = [
    InlineKeyboardButton(f"{districts.mow_metro4}, Магнит", callback_data=heads_mow.new(1)),
    InlineKeyboardButton(f"{districts.mow_metro36}, Прикоп", callback_data=heads_mow.new(2)),
    InlineKeyboardButton(f"{districts.mow_metro37}, Магнит", callback_data=heads_mow.new(3)),
    InlineKeyboardButton(f"{districts.mow_metro55}, Магнит", callback_data=heads_mow.new(4)),
    InlineKeyboardButton(f"{districts.mow_metro162}, Тайник", callback_data=heads_mow.new(5)),
    InlineKeyboardButton("Назад 🔙", callback_data=heads_mow.new('back_mow'))
]

p5_shop_mow_mephflour_buttons = [
    InlineKeyboardButton(f"{districts.mow_metro2}, Магнит", callback_data=mephflour_mow.new(1)),
    InlineKeyboardButton(f"{districts.mow_metro21}, Тайник", callback_data=mephflour_mow.new(2)),
    InlineKeyboardButton(f"{districts.mow_metro66}, Магнит", callback_data=mephflour_mow.new(3)),
    InlineKeyboardButton(f"{districts.mow_metro100}, Магнит", callback_data=mephflour_mow.new(4)),
    InlineKeyboardButton(f"{districts.mow_metro111}, Тайник", callback_data=mephflour_mow.new(5)),
    InlineKeyboardButton(f"{districts.mow_metro152}, Магнит", callback_data=mephflour_mow.new(6)),
    InlineKeyboardButton(f"{districts.mow_metro166}, Прикоп", callback_data=mephflour_mow.new(7)),
    InlineKeyboardButton(f"{districts.mow_distr3}, Прикоп", callback_data=mephflour_mow.new(8)),
    InlineKeyboardButton(f"{districts.mow_distr10}, Тайник", callback_data=mephflour_mow.new(9)),
    InlineKeyboardButton("Назад 🔙", callback_data=mephflour_mow.new('back_mow'))
]

p5_shop_mow_mephcryst_buttons = [
    InlineKeyboardButton(f"{districts.mow_metro16}, Магнит", callback_data=mephcryst_mow.new(1)),
    InlineKeyboardButton(f"{districts.mow_metro78}, Тайник", callback_data=mephcryst_mow.new(2)),
    InlineKeyboardButton(f"{districts.mow_metro89}, Магнит", callback_data=mephcryst_mow.new(3)),
    InlineKeyboardButton(f"{districts.mow_metro105}, Магнит", callback_data=mephcryst_mow.new(4)),
    InlineKeyboardButton(f"{districts.mow_metro111}, Тайник", callback_data=mephcryst_mow.new(5)),
    InlineKeyboardButton(f"{districts.mow_metro115}, Тайник", callback_data=mephcryst_mow.new(6)),
    InlineKeyboardButton(f"{districts.mow_metro118}, Магнит", callback_data=mephcryst_mow.new(7)),
    InlineKeyboardButton(f"{districts.mow_metro131}, Тайник", callback_data=mephcryst_mow.new(8)),
    InlineKeyboardButton(f"{districts.mow_metro147}, Магнит", callback_data=mephcryst_mow.new(9)),
    InlineKeyboardButton(f"{districts.mow_distr1}, Магнит", callback_data=mephcryst_mow.new(10)),
    InlineKeyboardButton(f"{districts.mow_distr12}, Тайник", callback_data=mephcryst_mow.new(11)),
    InlineKeyboardButton("Назад 🔙", callback_data=mephcryst_mow.new('back_mow'))
]

p5_shop_mow_apvp_buttons = [
    InlineKeyboardButton(f"{districts.mow_metro8}, Магнит", callback_data=apvp_mow.new(1)),
    InlineKeyboardButton(f"{districts.mow_metro38}, Тайник", callback_data=apvp_mow.new(2)),
    InlineKeyboardButton(f"{districts.mow_metro47}, Магнит", callback_data=apvp_mow.new(3)),
    InlineKeyboardButton(f"{districts.mow_metro65}, Прикоп", callback_data=apvp_mow.new(4)),
    InlineKeyboardButton(f"{districts.mow_metro84}, Тайник", callback_data=apvp_mow.new(5)),
    InlineKeyboardButton(f"{districts.mow_metro91}, Прикоп", callback_data=apvp_mow.new(6)),
    InlineKeyboardButton(f"{districts.mow_metro99}, Тайник", callback_data=apvp_mow.new(7)),
    InlineKeyboardButton(f"{districts.mow_metro127}, Магнит", callback_data=apvp_mow.new(8)),
    InlineKeyboardButton(f"{districts.mow_distr1}, Магнит", callback_data=apvp_mow.new(9)),
    InlineKeyboardButton(f"{districts.mow_distr7}, Тайник", callback_data=apvp_mow.new(10)),
    InlineKeyboardButton(f"{districts.mow_distr12}, Прикоп", callback_data=apvp_mow.new(11)),
    InlineKeyboardButton("Назад 🔙", callback_data=apvp_mow.new('back_mow'))
]



# IWA PRODUCTS 
p5_shop_iwa_heads_buttons = [
    InlineKeyboardButton(f"{districts.iwa_distr2}, Магнит", callback_data=heads_iwa.new(1)),
    InlineKeyboardButton(f"{districts.iwa_distr4}, Прикоп", callback_data=heads_iwa.new(2)),
    InlineKeyboardButton("Назад 🔙", callback_data=heads_iwa.new('back_iwa'))
]

p5_shop_iwa_mephcryst_buttons = [
    InlineKeyboardButton(f"{districts.iwa_distr3}, Магнит", callback_data=mephcryst_iwa.new(1)),
    InlineKeyboardButton("Назад 🔙", callback_data=mephcryst_iwa.new('back_iwa'))
]

p5_shop_iwa_apvp_buttons = [
    InlineKeyboardButton(f"{districts.iwa_distr2}, Магнит", callback_data=apvp_iwa.new(1)),
    InlineKeyboardButton(f"{districts.iwa_distr3}, Прикоп", callback_data=apvp_iwa.new(2)),
    InlineKeyboardButton("Назад 🔙", callback_data=apvp_iwa.new('back_iwa'))
]



# PES PRODUCTS 
p5_shop_pes_hash_buttons = [
    InlineKeyboardButton(f"{districts.pes_distr1}, Тайник", callback_data=hash_pes.new(1)),
    InlineKeyboardButton("Назад 🔙", callback_data=hash_pes.new('back_pes'))
]

p5_shop_pes_heads_buttons = [
    InlineKeyboardButton(f"{districts.pes_distr1}, Тайник", callback_data=heads_pes.new(1)),
    InlineKeyboardButton("Назад 🔙", callback_data=heads_pes.new('back_pes'))
]

p5_shop_pes_mephcryst_buttons = [
    InlineKeyboardButton(f"{districts.pes_distr2}, Магнит", callback_data=mephcryst_pes.new(1)),
    InlineKeyboardButton(f"{districts.pes_distr5}, Тайник", callback_data=mephcryst_pes.new(2)),
    InlineKeyboardButton("Назад 🔙", callback_data=mephcryst_pes.new('back_pes'))
]

p5_shop_pes_apvp_buttons = [
    InlineKeyboardButton(f"{districts.pes_distr3}, Тайник", callback_data=apvp_pes.new(1)),
    InlineKeyboardButton(f"{districts.pes_distr4}, Магнит", callback_data=apvp_pes.new(2)),
    InlineKeyboardButton("Назад 🔙", callback_data=apvp_pes.new('back_pes'))
]
    

p5_shop_purchase_buttons = [
    InlineKeyboardButton("Я оплатил", callback_data=shop_purchase_decision.new('ok')),
    InlineKeyboardButton("Оплатить с BTC - кошелька", callback_data=shop_purchase_decision.new('ok_btc')),
    InlineKeyboardButton("Отмена", callback_data=shop_purchase_decision.new('stop'))
]
