import random
from string import digits, ascii_uppercase
from random import choice


def generate_alphanum_random_string():
    chars = digits + ascii_uppercase
    random_strings_list = ["".join([choice(chars) for i in range(12)]) for j in range(100)]
    return random_strings_list

request_id = generate_alphanum_random_string()
