from aiogram.utils.callback_data import CallbackData

call_city = CallbackData('cities', "city")

pos_variable = CallbackData('position', 'var')

hash_mow = CallbackData('hash_mow', 'var')
heads_mow = CallbackData('heads_mow', 'var')
mephflour_mow = CallbackData('mephflour_mow', 'var')
mephcryst_mow = CallbackData('mephcryst_mow', 'var')
apvp_mow = CallbackData('apvp_mow', 'var')

heads_iwa = CallbackData('heads_iwa', 'var')
mephcryst_iwa = CallbackData('mephcryst_iwa', 'var')
apvp_iwa = CallbackData('apvp_iwa', 'var')

hash_pes = CallbackData('hash_pes', 'var')
heads_pes = CallbackData('heads_pes', 'var')
mephcryst_pes = CallbackData('mephcryst_pes', 'var')
apvp_pes = CallbackData('apvp_pes', 'var')

shop_purchase_decision = CallbackData('decisions', 'var')

funds = CallbackData('funds_choose', 'var')
funds_wallet = CallbackData('wallet_choose', 'var')
funds_wallet_withdrawal = CallbackData('payment_methods', 'var')

work = CallbackData('jobs', 'var')

support = CallbackData('variants', 'var')
