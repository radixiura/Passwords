# Hash
hash1 = "Гашиш Ice - o - Lator CR7, 1гр"
hash1_price = "2200р"
hash1_btc_price = "0.0013 BTC"
hash1_about = "https://ibb.co/qjmrC9g https://ibb.co/55GmbG3"

hash2 = "Гашиш EURO+, 1гр"
hash2_price = "1800р"

# Heads
heads1 = "Шишки White widow, 1гр"
heads1_price = "1850р"
heads1_btc_price = "0.0011 BTC"
heads1_about = "https://ibb.co/3fKKM3j https://ibb.co/Pr1S7Tk"

heads2 = "Шишки Purple haze, 1гр"
heads2_price = "2000р"

# Mephflour
mephflour1 = "Меф мука Kiss, 1гр"
mephflour1_price = "1700р"
mephflour1_btc_price = "0.0009 BTC"
mephflour1_about = "https://ibb.co/d6zy8wF https://ibb.co/3s8hpDX"

# Mephcryst
mephcryst1 = "Меф крисы Miami, 0.5гр"
mephcryst1_price = "1100р"
mephcryst1_btc_price = "0.0007 BTC"
mephcryst1_about = "https://ibb.co/br87ZFz https://ibb.co/XssM3B0"

# Apvp
apvp1 = "A-pvp крисы Lightspeed, 0.35гр"
apvp1_price = "800р"
apvp1_btc_price = "0.0005 BTC"
apvp1_about = "https://ibb.co/42g6jS3 https://ibb.co/kG9nSy2"
