current_balance = "0р"
current_btc_balance = "0.0000 BTC"
