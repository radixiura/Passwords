# IMPORTS #
import logging
import random

from aiogram import Bot, types
from aiogram.utils import executor
from aiogram.dispatcher import Dispatcher

from conf import config
import keyboards as kb
from messages.work_messages import *

from vars.callback_factory import call_city, \
 pos_variable, \
 hash_mow, heads_mow, mephflour_mow, mephcryst_mow, apvp_mow, \
 heads_iwa, mephcryst_iwa, apvp_iwa, \
 hash_pes, heads_pes, mephcryst_pes, apvp_pes, \
 shop_purchase_decision, \
 funds, funds_wallet, funds_wallet_withdrawal, \
 work, \
 support

from vars import cities, products, districts

from vars.special import requisites, request

from vars.finance import wallet
#-IMPORTS-#


# STARTING #
logging.basicConfig(level=logging.INFO)
bot = Bot(token=config.bot_token)
dp = Dispatcher(bot)
#-STARTING-#


# MAIN COMMANDS #
@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message):
    await message.answer(f"Привет, {message.from_user.first_name}!", reply_markup=kb.p5_main_mrkp)

@dp.message_handler(commands=['main'])
async def process_start_command(message: types.Message):
    await message.answer("Главное меню:", reply_markup=kb.p5_main_mrkp)

@dp.message_handler(commands=['shop'])
async def process_start_command(message: types.Message):
    await message.answer("Выберите ваш город:", reply_markup=kb.p5_shop_mrkp)

@dp.message_handler(commands=['funds'])
async def process_start_command(message: types.Message):
    await message.answer("Ваши средства:", reply_markup=kb.p5_funds_mrkp)

@dp.message_handler(commands=['support'])
async def process_start_command(message: types.Message):
    await message.answer("Выберите действие:", reply_markup=kb.p5_support_mrkp)
#-MAIN COMMANDS-#

# SHOP HADLERS #
@dp.callback_query_handler(text="p5_shop_signal")
async def process_callback_button(callback: types.CallbackQuery):
    await callback.message.answer("Выберите ваш город:", reply_markup=kb.p5_shop_mrkp)


@dp.callback_query_handler(call_city.filter())
async def process_callback_button(callback: types.CallbackQuery, callback_data: dict):
    match callback_data.get('city'):
        case 'Москва':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
        case 'Иваново':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_iwa_mrkp)
        case 'Люберцы':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_lub_mrkp)
        case 'Петрозаводск':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
        case 'Раменское':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_ram_mrkp)
        case 'Рязань':
            await callback.message.answer("Выберите товар:", reply_markup=kb.p5_shop_rya_mrkp)
        case _:
            await callback.message.answer('Poka nedostupno!')


@dp.callback_query_handler(pos_variable.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'hash_mow':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_mow_hash_mrkp)
        case 'hash_pes':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_pes_hash_mrkp)
        case 'heads_mow':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_mow_heads_mrkp)
        case 'heads_iwa':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_iwa_heads_mrkp)
        case 'heads_pes':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_pes_heads_mrkp)
        case 'mephflour_mow':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_mow_mephflour_mrkp)
        case 'mephcryst_mow':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_mow_mephcryst_mrkp)
        case 'mephcryst_iwa':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_iwa_mephcryst_mrkp)
        case 'mephcryst_pes':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_pes_mephcryst_mrkp)
        case 'apvp_mow':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_mow_apvp_mrkp)
        case 'apvp_iwa':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_iwa_apvp_mrkp)
        case 'apvp_pes':
            await callback_query.message.answer("Выберите локацию:", reply_markup=kb.p5_shop_pes_apvp_mrkp)
        case 'back':
            await callback_query.message.answer("Выберите ваш город:", reply_markup=kb.p5_shop_mrkp)
            return
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
        case 'back_iwa':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_iwa_mrkp)
            return
        case 'back_pes':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
            return


""""""""""""""""""""""""""""""""""""""" MOSCOW """""""""""""""""""""""""""""""""""""""

@dp.callback_query_handler(hash_mow.filter())
async def get_hash_mow(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro4, 'Тайник',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro6, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '3':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro39, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '4':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro45, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '5':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro50, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '6':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro55, 'Тайник',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '7':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro60, 'Тайник',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '8':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_metro115, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '9':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_distr1, 'Тайник',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case '10':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.mow_distr2, 'Магнит',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(heads_mow.filter())
async def get_heads_mow(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.mow_metro4, 'Магнит',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.mow_metro36, 'Прикоп',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case '3':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.mow_metro37, 'Магнит',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case '4':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.mow_metro55, 'Магнит',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case '5':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.mow_metro162, 'Тайник',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(mephflour_mow.filter())
async def get_mephflour_mow(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro2, 'Магнит',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro21, 'Тайник',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '3':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro66, 'Магнит',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '4':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro100, 'Магнит',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '5':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro111, 'Тайник',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '6':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro152, 'Магнит',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '7':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_metro166, 'Прикоп',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '8':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_distr3, 'Прикоп',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case '9':
            message = message.format(random.choice(request.request_id),
             products.mephflour1,
             districts.mow_distr10, 'Тайник',
             products.mephflour1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, products.mephflour1_btc_price,
             products.mephflour1_price, requisites.card_number)
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(mephcryst_mow.filter())
async def get_mephcryst_mow(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro16, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro78, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '3':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro89, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '4':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro105, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '5':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro111, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '6':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro115, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '7':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro118, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '8':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro131, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '9':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_metro147, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '10':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_distr1, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '11':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.mow_distr12, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(apvp_mow.filter())
async def get_apvp_mow(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro8, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro38, 'Тайник',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '3':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro47, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '4':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro65, 'Прикоп',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '5':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro84, 'Тайник',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '6':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro91, 'Прикоп',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '7':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro99, 'Тайник',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '8':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_metro127, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '9':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_distr1, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '10':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_distr7, 'Тайник',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '11':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.mow_distr12, 'Прикоп',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case 'back_mow':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_mow_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


""""""""""""""""""""""""""""""""""""""" IVANOVO """""""""""""""""""""""""""""""""""""""

@dp.callback_query_handler(heads_iwa.filter())
async def get_heads_iwa(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.iwa_distr2, 'Магнит',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.iwa_distr4, 'Прикоп',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case 'back_iwa':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_iwa_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')

@dp.callback_query_handler(mephcryst_iwa.filter())
async def get_mephcryst_iwa(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.iwa_distr3, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case 'back_iwa':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_iwa_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')

@dp.callback_query_handler(apvp_iwa.filter())
async def get_apvp_iwa(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.iwa_distr2, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.iwa_distr3, 'Прикоп',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case 'back_iwa':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_iwa_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')
#--------------------#

""""""""""""""""""""""""""""""""""""""" PETROZAVODSK """""""""""""""""""""""""""""""""""""""

@dp.callback_query_handler(hash_pes.filter())
async def get_hash_pes(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.hash1,
             districts.pes_distr1, 'Тайник',
             products.hash1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, products.hash1_btc_price,
             products.hash1_price, requisites.card_number)
        case 'back_pes':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(heads_pes.filter())
async def get_heads_pes(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.heads1,
             districts.pes_distr1, 'Тайник',
             products.heads1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, products.heads1_btc_price,
             products.heads1_price, requisites.card_number)
        case 'back_pes':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')

@dp.callback_query_handler(mephcryst_pes.filter())
async def get_mephcryst_pes(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.pes_distr2, 'Магнит',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.mephcryst1,
             districts.pes_distr5, 'Тайник',
             products.mephcryst1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, products.mephcryst1_btc_price,
             products.mephcryst1_price, requisites.card_number)
        case 'back_pes':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')


@dp.callback_query_handler(apvp_pes.filter())
async def get_apvp_pes(callback_query: types.CallbackQuery, callback_data: dict):
    message = '''Номер заявки: <code>{}</code>

Товар: <b>{}</b>
Локация: <b>{}</b>, {}
<em>О товаре: <u>{}</u></em>

Ваш текущий баланс: <code>{}/{}</code>
Стоимость: <code>{}/{}</code>
Не хватает: <code>{}/{}</code>

Переведите <code>{}</code> на <u><b>{}</b></u>

ВНИМАНИЕ!
Не отменяйте заявку если уже оплатили заказ. Не оставляйте на месте следы от упаковки!'''
    match callback_data.get('var'):
        case '1':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.pes_distr3, 'Тайник',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case '2':
            message = message.format(random.choice(request.request_id),
             products.apvp1,
             districts.pes_distr4, 'Магнит',
             products.apvp1_about,
             wallet.current_balance, wallet.current_btc_balance,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, products.apvp1_btc_price,
             products.apvp1_price, requisites.card_number)
        case 'back_pes':
            await callback_query.message.answer("Выберите товар:", reply_markup=kb.p5_shop_pes_mrkp)
            return
    await callback_query.message.answer(message, reply_markup=kb.p5_shop_purchase_mrkp, parse_mode='html')
#--------------------#


# Oplata
@dp.callback_query_handler(shop_purchase_decision.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'ok':
            await callback_query.message.answer("Оплата все еще ожидается! Если в течении 30 минут вам не пришло фото с описанием - обратитесь к модератору (@glavpopadiku)")
        case 'ok_btc':
            await callback_query.message.answer("На вашем BTC - кошельке недостаточно средств.")
        case 'stop':
            await callback_query.message.answer("Заявка успешно отменена.")
            await callback_query.message.answer("Выберите ваш город:", reply_markup=kb.p5_shop_mrkp)
            return
#-SHOP HADLERS-#


# FUNDS HANDLERS #
@dp.callback_query_handler(text="p5_funds_signal")
async def process_callback_button(callback_query: types.CallbackQuery):
    await callback_query.message.answer("Выберите, что вам нужно:", reply_markup=kb.p5_funds_mrkp)

@dp.callback_query_handler(funds.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'p5_funds_wallet_signal':
            await callback_query.message.answer("Выберите, что вам нужно:", reply_markup=kb.p5_funds_wallet_mrkp)
        case 'p5_funds_btcwallet_signal':
            await callback_query.message.answer("Ваш BTC - кошелек:")
            await callback_query.message.answer(f"{requisites.btcwallet_number}")
        case 'p5_funds_coupons_signal':
            await callback_query.message.answer("Ваши купоны: ")
        case 'p5_main_menu_signal':
            await callback_query.message.answer("Возврат к главному меню", reply_markup=kb.p5_main_mrkp)
            return


@dp.callback_query_handler(funds_wallet.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'p5_funds_wallet_balance_signal':
            await callback_query.message.answer(f"Ваш баланс: {wallet.current_balance} / {wallet.current_btc_balance}", reply_markup=kb.p5_funds_wallet_mrkp)
        case 'p5_funds_wallet_withdrawal_signal':
            await callback_query.message.answer("Выберите способ вывода", reply_markup=kb.p5_funds_wallet_withdrawal_mrkp)
        case 'p5_main_menu_signal':
            await callback_query.message.answer("Возврат к главному меню", reply_markup=kb.p5_main_mrkp)
            return


@dp.callback_query_handler(funds_wallet_withdrawal.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'p5_funds_wallet_withdrawal_card_signal':
            await callback_query.message.answer("Введите номер карты для вывода средств") # make a handler for inserted card - answering withdrawal is av. up to 300 roubles.
        case 'p5_funds_wallet_withdrawal_qiwi_signal':
            await callback_query.message.answer("Вывод на Qiwi - кошелек временно недоступен")
        case 'p5_funds_wallet_withdrawal_btcwallet_signal':
            await callback_query.message.answer("Введите BTC - кошелек для вывода средств")
        case 'p5_main_menu_signal':
            await callback_query.message.answer("Возврат к главному меню", reply_markup=kb.p5_main_mrkp)
            return
#-FUNDS HADLERS-#


# WORK HANDLERS #
@dp.callback_query_handler(text="p5_work_signal")
async def process_callback_button(callback_query: types.CallbackQuery):
    await callback_query.message.answer('''Время поработать 😃
Кем вы бы хотели устроиться?''', reply_markup=kb.p5_work_mrkp)

@dp.callback_query_handler(work.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'p5_work_courier_signal':
            await callback_query.message.answer(courier_message)
        case 'p5_work_artist_signal':
            await callback_query.message.answer(artist_message)
        case 'p5_work_designer_signal':
            await callback_query.message.answer(designer_message)
        case 'p5_work_advertiser_signal':
            await callback_query.message.answer(advertiser_message)
        case 'p5_main_menu_signal':
            await callback_query.message.answer("Возврат к главному меню", reply_markup=kb.p5_main_mrkp, parse_mode='html')
            return
#-WORK HANDLERS-#


# SUPPORT HANDLERS #
@dp.callback_query_handler(text="p5_support_signal")
async def process_callback_button(callback_query: types.CallbackQuery):
    await callback_query.message.answer("Выберите действие:", reply_markup=kb.p5_support_mrkp)

@dp.callback_query_handler(support.filter())
async def process_callback_button(callback_query: types.CallbackQuery, callback_data: dict):
    match callback_data.get('var'):
        case 'p5_support_instruction_signal':
            await callback_query.message.answer('''Kak lalala - https
kak nanana - https''', reply_markup=kb.p5_support_mrkp)
        case 'p5_support_feedback_signal':
            await callback_query.message.answer('''Вы всегда можете написать администрации: @glavpopadiku
Также, у нас есть чат!: @padik5chat''', reply_markup=kb.p5_support_mrkp)
        case 'p5_support_about_signal':
            await callback_query.message.answer("https://www.youtube.com/watch?v=aPfd6-4F1xU")
        case 'p5_main_menu_signal':
            await callback_query.message.answer("Возврат к главному меню", reply_markup=kb.p5_main_mrkp)
            return
#-SUPPORT HANDLERS-#

# REVIEWS HANDLERS #
@dp.callback_query_handler(text="p5_reviews_signal")
async def process_callback_button(callback_query: types.CallbackQuery):
    await callback_query.message.answer("@padik5reviews")
#-REVIEWS HANDLERS-#


# ADDITIONAL HANDLERS #
@dp.callback_query_handler(text="p5_main_menu_signal")
async def process_callback_button(callback_query: types.CallbackQuery):
    await callback_query.message.answer("Возврат к главному меню:", reply_markup=kb.p5_main_mrkp)
#-ADDITIONAL HANDLERS-#

# MESSAGES CHECKING #
if __name__ == '__main__':
    executor.start_polling(dp)
#-MESSAGES CHECKING-#
