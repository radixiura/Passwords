# User authentication - get login
# Content:

# -*- coding: utf-8 -*-

import time
import sqlq.sql_queries

connect_to_db = sqlq.sql_queries


# 1.1 Функция получения логина пользователя
def aut_get_login():
    user_login = input("Введите логин: ")

    # 1.1.2 Запрос на проверку существования логина
    query_for_login_check = f"SELECT ALL login_name FROM users WHERE login_name='{user_login}'"
    user_login_checking = sqlq.sql_queries.execute_query(connect_to_db, query_for_login_check)

    user_login_correct = False
    while not user_login_correct:
        if not user_login_checking:
            print(f"Ваш логин не найден в БД")
            aut_get_login()
        else:
            print("заебато")
            user_login_correct = True
    return user_login
