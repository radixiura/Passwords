# User authentication - get password
# Content:

# -*- coding: utf-8 -*-

import sqlq.sql_queries

connect_to_db = sqlq.sql_queries


# 1.1 Функция получения пароля пользователя
def aut_get_password():
    # 1.1.2 Получение пароля пользователем
    user_password = input("Введите пароль: ")

    # 1.1.2 Запрос на проверку существования пароля
    query_for_password_check = f"SELECT ALL password FROM users WHERE password='{user_password}'"
    user_password_checking = sqlq.sql_queries.execute_query(connect_to_db, query_for_password_check)

    user_password_correct = False
    while not user_password_correct:
        if not user_password_checking:
            print(f"Ваш логин не найден в БД")
            aut_get_password()
        else:
            print("заебато")
            user_password_correct = True
    return user_password
