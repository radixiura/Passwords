# New user registration
# Content:

# -*- coding: utf-8 -*-

import time
import sqlq.sql_queries
from entry_funcs.user_aut_funcs import user_aut_get_login, user_aut_get_password

connect_to_db = sqlq.sql_queries


# 1.1 Функция входа пользователя
def aut_func():
    # 1.1.1 Получение логина пользователя
    login = user_aut_get_login.aut_get_login()
    # 1.1.2 Получение пароля пользователя
    password = user_aut_get_password.aut_get_password()

    # 1.1.3 Запрос на проверку существования пароля
    query_for_check = f"SELECT ALL password FROM users WHERE password='{password}'"
    password_checking = sqlq.sql_queries.execute_read_query(connect_to_db, query_for_check)

    password_correct = False
    while not password_correct:
        if not password_checking:
            print("Логин или пароль введены неправильно! Попробуйте еще раз")
            auth_func()
        else:
            print(f"{login}, вы успешно вошли.")
            password_correct = True
    return login, password
