# New user registration
# Content:

# -*- coding: utf-8 -*-

import time
import sqlq.sql_queries
from entry_funcs.new_user_reg_funcs import new_user_reg_get_login, new_user_reg_get_password

connect_to_db = sqlq.sql_queries


# Часть 1
# 1.1 Функция регистрации пользователя
def reg_func():
    # 1.1.1 Получение логина нового пользователя
    login = new_user_reg_get_login.reg_get_login()
    # 1.1.2 Получение пароля нового пользователя
    password = new_user_reg_get_password.reg_get_password()

    # 1.1.3 Подтверждение пароля нового пользователя
    new_user_password_confirmation_input = input("Введите свой новый пароль еще раз: ")
    while new_user_password_confirmation_input != password:
        time.sleep(3)
        print('''
Введенные пароли не сходятся. Попробуйте еще раз.''')
        new_user_password_confirmation_input = input("Введите свой новый пароль еще раз: ")
        if new_user_password_confirmation_input == password:
            break

    # 1.1.4 Добавление нового пользователя в БД
    add_new_user = f"""
    INSERT INTO
        users (login_name, password, rank)
    VALUES
        ('{login}', '{password}', 'slave')
    """
    sqlq.sql_queries.execute_query(connect_to_db, add_new_user)
