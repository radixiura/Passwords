# New user registration - get password
# Content:

# -*- coding: utf-8 -*-

import sqlq.sql_queries
import time

# Скрипт создания подключения к бд
connect_to_db = sqlq.sql_queries.connection


# Часть 1
# 1.1 Функция получения пароля нового пользователя
def reg_get_password():
    new_user_password = input("Введите ваш новый пароль: ")

    new_user_password_correct = False
    while not new_user_password_correct:
        if len(new_user_password) < 8:
            time.sleep(3)
            print('''
Пароль должен содержать более 8ми символов. Попробуйте заново.''')
            new_user_password = input("Введите ваш новый пароль: ")
        else:
            print(f"Ваш новый пароль: {new_user_password}")
            new_user_password_correct = True
    return new_user_password
    
