# New user registration - get login
# Content:

# -*- coding: utf-8 -*-

import time
import sqlq.sql_queries

connect_to_db = sqlq.sql_queries.connection


# 1.1 Функция получения логина нового пользователя
def reg_get_login():
    new_user_login = input("Самое время зарегистрироваться. Введите свой новый логин: ")

    # 1.1.2 Запрос на проверку существования логина
    query_for_login_check = f"SELECT ALL login_name FROM users WHERE login_name='{new_user_login}'"
    user_login_checking = sqlq.sql_queries.execute_query(connect_to_db, query_for_login_check)

    new_user_login_correct = False
    while not new_user_login_correct:
        if len(new_user_login) < 8:
            time.sleep(3)
            print("Логин должен содержать более 8ми символов. Попробуйте заново.\n")
            new_user_login = input("Введите свой новый логин еще раз: ")
        elif user_login_checking:
            print("Этот логин уже занят. Попробуйте заново.\n")
            new_user_login = input("Введите свой новый логин еще раз: ")
        else:
            print(f"Ваш новый логин: {new_user_login}")
            new_user_login_correct = True
    return new_user_login
    
