def greeting_func():
    user_answer = input('''Привет!
Вы уже имеете аккаунт? Введите 1 если да, 0 если нет: ''')
    return user_answer
