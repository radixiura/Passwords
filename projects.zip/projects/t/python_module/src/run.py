# Main file
# Content:

# -*- coding: utf-8 -*-

from entry_funcs import greeting, new_user_reg, user_aut
from main_menu_modules import main_menu

# 1.1
user_answer_entry = greeting.greeting_func()
# 1.2
user_answer_entry_correct = False
while not user_answer_entry_correct:
    if user_answer_entry == "0":
        new_user_reg.reg_func()
        user_answer_entry_correct = True
    elif user_answer_entry == "1":
        print("Отлично!")
        user_answer_entry_correct = True
    else:
        print("Ошибка! Вы ввели что - то странное, попробуйте еще раз.")
        greeting.greeting_func()


# Часть 2
# 2.1
user_aut.aut_func()
main_menu.main_menu_buttons()
